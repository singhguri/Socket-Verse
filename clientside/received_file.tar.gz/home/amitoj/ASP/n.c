#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include<sys/wait.h>
#include<string.h>
 
 
 
int main(){

//int pid1,pid2,pid3,pid4;
	printf("%d %d  %d  %d\n",getpid(),getgid(),getpgrp(), getpgid(2033));
}
