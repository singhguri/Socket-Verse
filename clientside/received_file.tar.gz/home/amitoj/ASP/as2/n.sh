#!/bin/bash

# Fork the process
forked_process() {
  sleep 10
  echo "Child process completed."
}

echo "Forking a child process..."
forked_process &

# Wait a few seconds to give the child process a chance to become a zombie
sleep 200

echo "Parent process completed."

