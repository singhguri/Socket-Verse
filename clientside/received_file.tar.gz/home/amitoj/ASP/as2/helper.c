
// C program to demonstrate waitpid()
#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>
#include<unistd.h>
 

 

int main()
{	
	
	int p1=fork();
	int p2= fork();
	int p3=fork();
//	int p4=fork();
	
	if(p3==0){
		printf("exit child : %d %d\n",getpid(),getppid());
		sleep(1);
		exit(0);
	}
	else if(p1==0 || p2==0 ||p3==0 ){
		printf("child : %d %d\n",getpid(),getppid());
		for(;;)
		sleep(100000);
//		exit(0);
		
	}
    else{
		printf("Parent :  %d %d\n",getpid(),getppid());
		for(;;)
		sleep(100000);
		
		}
}
