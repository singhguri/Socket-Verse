#! /bin/bash

if [ $# -eq 0 ];
then
	## if no input file provided
	echo "No input files"
elif [ $# -gt 5 ];
then
	#if more input file provided
	echo "More than 5 files provided"
else
	# run until loop till the values are less than 6
	counter=1
	until [ $counter -gt $# ]
	do
		
		#echo $1
		case $counter in
		
		1) if [[ $1 == "*.txt" ]]
		then
			echo "Not a text file"
		else
			cat $1 >> output.txt 
		fi;;
		2) if [[ $2 == "*.txt" ]]
		then
			echo "Not a text file"
		else
			cat $2 >> output.txt
		fi;;
		3) if [[ $3 == "*.txt" ]]
		then
			echo "Not a text file"
		else
		 	cat $3 >> output.txt
		fi;;
		4) if [[ $4 == "*.txt" ]]
			then 
				echo "Not a text file"
		else
			  cat $4 >> output.txt
		fi;;
		5) if [[ $5 == "*.txt" ]]
			then
				echo "not a text file"
			else
			cat $5 >> output.txt
			fi;;
		esac
		
	counter=$(( $counter + 1 ))
	done
fi
