//#include <stdio.h>
//#include <stdlib.h>
//#include <unistd.h>
//#include <fcntl.h>
// 
// //equivalent of $ls|wc -w 
// 
//int main(int argc, char *argv[]){
//int fd[2];
//
//if(pipe(fd)==-1) exit(1);
//
//	if(fork() == 0){
//		//child
//		int fd2[2];
//		
////		if(pipe(fd2)==-1) exit(1);
//		
//		if(fork()>0){
//			
//			
////			close(fd[1]);
//			dup2(fd[0], 0); // 0 is the standard input
//			dup2(fd[1], 1); // 1 is the standard opt
//	//		
////			close(fd[1]);
////			close(fd[0]); // close original file descriptor
//			execlp("wc", "wc", "-c", NULL);
//				
//				//first child and a parent
//		
//		
//		}else{
//	
//		
//			close(fd[1]); // close original file descriptor
//	
//			
//			dup2(fd[0], 0); // 0 is the standard input
////						
////			close(fd[0]);
//////			close(fd[1]);
//			execlp("wc", "wc", "-w",NULL);
//			
//			
//			//child child
//		}
//				
//	}
//	else {
//		
//		//parent
//		
//			close(fd[0]);
//			
//			dup2(fd[1], 1); // 1 is the standard output
////			close(fd[1]); // close original file descriptor
//			
//			execlp("ls", "ls", NULL);
//		
//	
//	}
//}//End main
//
//
//#include <stdio.h>
//#include <stdlib.h>
//#include <unistd.h>
//
//int main() {
//    int pipefd[2];
//    pid_t pid;
//
//    // Create a pipe
//    if (pipe(pipefd) == -1) {
//        perror("pipe");
//        exit(EXIT_FAILURE);
//    }
//
//    // Fork a child process
//    pid = fork();
//    if (pid == -1) {
//        perror("fork");
//        exit(EXIT_FAILURE);
//    }
//
//    if (pid == 0) {
//        // Child process (command1)
//        close(STDOUT_FILENO);           // Close stdout
//        dup2(pipefd[1], STDOUT_FILENO); // Duplicate write end of the pipe to stdout
//        close(pipefd[0]);               // Close unused read end of the pipe
//
//        // Execute command1
//        execlp("ls", "ls", NULL);
//        perror("execlp");
//        exit(EXIT_FAILURE);
//    } else {
//        // Parent process
//        pid = fork();
//        if (pid == -1) {
//            perror("fork");
//            exit(EXIT_FAILURE);
//        }
//
//        if (pid == 0) {
//            // Child process (command2)
//            close(STDIN_FILENO);
//			close (STDOUT_FILENO);           // Close stdin
//            dup2(pipefd[0], STDIN_FILENO);
//			dup2(pipefd[1], STDOUT_FILENO); // Duplicate read end of the pipe to stdin
////            close(pipefd[1]);               // Close unused write end of the pipe
//
//            // Execute command2
//            execlp("wc", "wc","-c", NULL);
//            perror("execlp");
//            exit(EXIT_FAILURE);
//        } else {
//            // Parent process
////            close(pipefd[0]); // Close unused read end of the pipe
//            close (STDOUT_FILENO);           // Close stdin
//            dup2(pipefd[0], STDIN_FILENO);
//            // Execute command3
//            execlp("wc", "wc", NULL);
//            perror("execlp");
//            exit(EXIT_FAILURE);
//        }
//    }
//
//    return 0;
//}

