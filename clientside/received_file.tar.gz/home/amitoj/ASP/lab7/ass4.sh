#!/bin/bash

completeBackupCounter=20001
incrementalBackupCounter=10001
backupLogFile=~/home/backup/backup.log
completeBackupDir=~/home/backup/cb
incrementalBackupDir=~/home/backup/ib
dirToBackup="."
completeBackupNo=20001
incrementalBackupNo=10001
lastBackupTime=date
# This function is responsible for creating complete backup
takeCompleteBackup() {

    	# create complete backup dir,
	# with -p also creates parent dirs and gives no error if already existing
    	mkdir -p $completeBackupDir

    	# get current time and convert in the  particular format
    	
	backupDateTime=$(date)
	lastBackupTime=$backupDateTime
    	# Create name and path of tar file
    	backupTarFile="${completeBackupDir}/cb${completeBackupNo}.tar"

    	# Create a tar archive of all .txt files
	# where find commands find all the text file in directory tree
    	# -c for create and -f  for file name
	# -type f means to search for files only and -name is to search for specific name
	tar -cf "$backupTarFile" $(find "$dirToBackup" -type f -name "*.txt")

	# Update backup.log with the timestamp and the name of the tar file
    	echo "${backupDateTime} - cb${completeBackupNo}.tar was created" >> "$backupLogFile"

	# increment backupNo by 1
	completeBackupNo=$(( $completeBackupNo + 1 ))

}

# Function to create an incremental backup and update the backup.log file
takeIncrementalBackup() {
    backupId=$1
    # check and get the last complete backup
    lastBackedUp=$(ls -t "$completeBackupDir" | grep "^cb" | head -1)

    # If there is a complete backup, proceed for incremental Backup

    if [ -n "$lastBackedUp" ]; then

        # create incremental backup directoryy
	# -p also creates parent dirs and gives no error if already existing
        mkdir -p "$incrementalBackupDir"

	# get current time and convert in the  particular format
	
	backupDateTime=$(date)
	# Create name and path of tar file
        backupTarFile="${incrementalBackupDir}/ib${incrementalBackupNo}.tar"

        # Find all .txt files that are newly created or modified after last complete backup
        modifiedFiles=$(find "$dirToBackup" -type f -newermt "$lastBackupTime" -name "*.txt")
	
	lastBackupTime=$backupDateTime
	

        # If there are newly created or modified .txt files, proceed with incremental backup
        if [ -n "$modifiedFiles" ]; then

            # Create a tar of  modified files
            tar -cf "$backupTarFile" $modifiedFiles

            # Update backup.log with the timestamp and the name of the tar file
            echo "${backupDateTime} - ib${incrementalBackupNo}.tar was created" >> "$backupLogFile"
		
	    # increment backup no.
	    incrementalBackupNo=$(( $incrementalBackupNo + 1 ))
        else
            # Output the message to backuplog file
            echo "${backupDateTime} - No changes-Incremental backup was not created." >> "$backupLogFile"

        fi
    else
	# If no previous backup found print message
        echo "No previous complete backup found. Please create a complete backup first."
    fi
}

while (true)
do

	# call takeCompleteBackup function
	takeCompleteBackup

	# sleep for 2 min 
	sleep 30

	# Call the function to create an incremental backup
	takeIncrementalBackup 1
	sleep 30

	takeIncrementalBackup 2
	
	sleep 30

	takeIncrementalBackup 3

	sleep 30
done

