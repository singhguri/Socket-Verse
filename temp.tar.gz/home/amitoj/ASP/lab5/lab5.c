/*

Name: Amitoj Singh Ahuja
Section 2 ,Tue 8:30 - 11:20
Student Id: 110094594
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/signal.h>

int interuptCount=0;

void alarmHandler(int sig){ 
	interuptCount=0;
	
	alarm(5);
}

void interuptHandler(int sig){ 
	interuptCount++;
	if(interuptCount==2){
		interuptCount=0;
		exit(0);
	}
}






int main(){

	signal(SIGALRM, alarmHandler);
	signal(SIGINT,interuptHandler);
	alarm(5);

	while(1){
		printf("Welcome to Lab5 - Signals\n");
		sleep(1);
	
	}

	return 0;
}
