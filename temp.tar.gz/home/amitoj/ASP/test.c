#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>

#include<string.h>
 
 
 
int main(){

int pid1,pid2,pid3,pid4;
//	printf("%d %d  %d  %d\n",getpid(),getppid(),getpgrp(), getpgid(getpid()));
	
pid1=fork();

pid2=fork();

pid3=fork();

pid4=fork();

if(pid1==0||pid2==0||pid3==0||pid4==0){
//		printf("%d  %d  %d %d\n",getpid(),getppid(),getpgrp(), getpgid(getpid()));
////	for(;;) sleep(0.5);
//sleep(200);

printf("%d %d %d %d %d %d\n", getpid(),getppid(),pid1,pid2,pid3, pid4);

exit(0);

}

else

{

while(1)

sleep(1);

} }
