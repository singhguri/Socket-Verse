#!/bin/sh

count=0

while [ $count -lt 2000 ]
do
    #echo "Count: $count"
    count=`expr $count + 1`
done

