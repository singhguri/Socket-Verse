#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#define MAX_COMMANDS 8  // Maximum number of piped commands
#define MAX_ARGS 6      // Maximum number of arguments per command
   int pipe_fd[7][2];
   int fo;
//void execute_command(char *command[], int pipe_in, int pipe_out) {
//    pid_t pid = fork();
//    
//    if (pid < 0) {
//        perror("fork failed");
//        exit(EXIT_FAILURE);
//    } else if (pid == 0) {
//        if (pipe_out == 0) {
//        	//write output to pipe
//        	
//        	printf("in");
////            close(pipes[0][0]);
//			dup2(pipes[1], 1);
////			close(pipes[0][0]);
////            close(pipe_in);
//			
//		
//			close(pipes[1]); 
//		
//        }
//        
//        if (pipe_out != 0) {
//        	
//        	//read from pipe
//        	
//
////            close(pipes[0][1]);
//						
//			dup2(pipes[0], 0); // duplicating the standard input to pipe
//			close(pipes[0]); 
//            
////close(pipes[0][1]);
//        }
//        
//		
////		printf("\n%s\n", command[0]);
//        
//        execvp(command[0], command);
//        perror("execvp failed");
//        exit(EXIT_FAILURE);
//    } else {
//        wait(NULL);
//    }
//}

void parse_command(char *input, char *commands[MAX_COMMANDS][MAX_ARGS]) {
    int command_count = 0;
    char * pt;
    char *token = strtok_r(input, "|", &pt);
    int arg_count=0;
    while (token != NULL && command_count < MAX_COMMANDS) {
    	printf("%s\n",token);
        char *arg_token = strtok(token, " ");
        arg_count = 0;
        while (arg_token != NULL && arg_count < MAX_ARGS - 1) {
            commands[command_count][arg_count] = arg_token;
            
            arg_count++;
            arg_token = strtok(NULL, " ");
        }
        
        commands[command_count][arg_count] = NULL;
        command_count++;

        
        token = strtok_r(NULL, "|", &pt);
    }


	commands[command_count][0]=NULL;

}



void execute_command(char * command[MAX_ARGS],int firstPipeInUse,int firstCommand, int lastCommand,int pipe1_in,int pipe2_in,int pipe1_out,int pipe2_out){

	int pid1=fork();

	if (pid1 == -1) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    } else if (pid1 == 0) {
    	
    	
    	for(int i=0;i<firstPipeInUse;i++){
			close(pipe_fd[i][0]);
			close(pipe_fd[i][1]);
		}
    	
    	if(firstCommand==1){
	    	
			close(pipe1_in);
			
			dup2(pipe1_out, 1); // 1 is the standard output
			close(pipe1_out); // close original file descriptor
			
			execlp("ls", "ls", NULL);
		
		}else if(lastCommand==1){
			   close(pipe1_in);
				close(pipe1_out); // close original file descriptor
				close(pipe2_out);
				
				dup2(pipe2_in, 0); // 0 is the standard input
	//						
				close(pipe2_in);
	    	
//	        dup2(pipe_out, STDOUT_FILENO);
//	        close(pipe_in);
//	        close(pipe_out);
	
	        // Execute ls
	        execvp(command[0], command);
	
	        // If execlp fails, print an error
	        perror("execlp ls failed");
	        exit(EXIT_FAILURE);
			
		
			
			
		}else{
	        	close(pipe1_out);
			dup2(pipe1_in, 0); // 0 is the standard input
			dup2(pipe2_out, 1); // 1is the standard opt
	//		
			close(pipe2_out);
			close(pipe2_in);
			close(pipe1_in); // close original file descriptor
	    	
//	    	
//		 	dup2(pipe_in, STDIN_FILENO);
//	        close(pipe_in);
//	        close(pipe_out);
//	
	        // Execute wc
	         execvp(command[0], command);
	
	        // If execlp fails, print an error
	        perror("execlp wc failed");
	        exit(EXIT_FAILURE);
			 
	    }
    }else{
    	
	}

}



void execute_pipeline(char *commands[MAX_COMMANDS][MAX_ARGS], int num_commands) {
 
    int i;
    
    for (i = 0; i < num_commands-1 ; i++) {
        if (pipe(pipe_fd[i]) == -1) {
            perror("pipe failed");
            exit(EXIT_FAILURE);
        }
    }
    
    for (i = 0; i < num_commands; i++) {		

			if(i==0)
 				execute_command(commands[i], 0, i==0?1:0,i==num_commands-1?1:0,pipe_fd[0][0],pipe_fd[1][0],pipe_fd[0][1],pipe_fd[1][1]);
 			else if(i!=num_commands-1){
			 execute_command(commands[i],i-1,  i==0?1:0,i==num_commands-1?1:0,pipe_fd[i-1][0],pipe_fd[i][0],pipe_fd[i-1][1],pipe_fd[i][1]);
			}else{
				
				execute_command(commands[i],i-2,  i==0?1:0,i==num_commands-1?1:0,pipe_fd[i-2][0],pipe_fd[i-1][0],pipe_fd[i-2][1],pipe_fd[i-1][1]);
			}
    
	}
    // Close pipe file descriptors in the parent process
    for(int i=0;i<num_commands-1;i++){
    close(pipe_fd[i][0]);
    close(pipe_fd[i][1]);}
    	
	for (i = 0; i < num_commands; i++) {
        wait(NULL);
    }
        
    
//    for (i = 0; i < num_commands - 1; i++) {
//        close(pipes[0]);
//        close(pipes[1]);
//    }
}

int main() {
    char input[256];
    char *commands[MAX_COMMANDS][MAX_ARGS];
    
    while (1) {
        printf("mshell$ ");
        fgets(input, sizeof(input), stdin);
        commands[0][0]=NULL;
        // Remove trailing newline character
        input[strcspn(input, "\n")] = '\0';
        
        parse_command(input, commands);
        
        int num_commands = 0;
        while (commands[num_commands][0] != NULL)
            num_commands++;
            
        printf("%d", num_commands);
        execute_pipeline(commands, num_commands);
    }
    
    return 0;
}

