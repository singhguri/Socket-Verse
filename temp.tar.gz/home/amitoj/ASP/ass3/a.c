#include<stdio.h>

int main(){
	int a[5];
	int c;
for(int i=0;i<5;i++){ scanf("%d %d",&a[i],&c);}

for(int i=0;i<5;i++) printf("%d\n\n%d\n\n", a[i],c);

	return 0;
}
