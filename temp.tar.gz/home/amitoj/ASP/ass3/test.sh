#!/bin/bash
while true
do
	echo "hello"
done
