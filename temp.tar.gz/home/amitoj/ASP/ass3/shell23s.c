/*
	Amitoj Singh Ahuja
	110094594
	Sec 2: 8:30-11:20
*/
#include <sys/wait.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
  
#define MAX_LENGTH_OF_COMMAND 100
#define MAX_NO_OF_COMMANDS_ALLOWED 8
#define MAX_NO_OF_OPERATORS_ALLOWED 7
#define MAX_NO_OF_ARGS_ALLOWED 5

int runProcessInBg = 0;
int pipeFileDesc[7][2];
char *commands[MAX_NO_OF_COMMANDS_ALLOWED+1][MAX_NO_OF_ARGS_ALLOWED+1];

// ================ Execute individual command in the pipeline ============
void executeIndividualPipeCommand(char * command[MAX_NO_OF_ARGS_ALLOWED+1],int firstPipeInUse,int firstCommand, int lastCommand,int pipe1ReadEnd,int pipe2ReadEnd,int pipe1WriteEnd,int pipe2WriteEnd){

	// fork a process
	int childPid=fork();

	if (childPid == -1) {
		// error while forking
        perror("Forking a child failed");
        exit(EXIT_FAILURE);
        
    } else if (childPid == 0) {
    	// In child process
    	
    	// close all the pipes that will not be used
    	for(int i=0;i<firstPipeInUse;i++){
			close(pipeFileDesc[i][0]);
			close(pipeFileDesc[i][1]);
		}
    	
    	
    	// if it is a first command
    	if(firstCommand==1){
    		// if it is a first command
    		// closing the pipe read end
			close(pipe1ReadEnd);
			// duplicate stdout to pipe
			dup2(pipe1WriteEnd, 1);
			//closing the write end
			close(pipe1WriteEnd); 
			//execute the command	
			execvp(command[0], command);   
		    
			// If execution failed
	        fprintf(stderr, "Execution Failed %s ", command[0]);
			perror("");
	        exit(EXIT_FAILURE);
		
		}else if(lastCommand==1){
			// if it is a last command
			// close the unused ends of pipes
			close(pipe1ReadEnd);
			close(pipe1WriteEnd);
			close(pipe2WriteEnd);	
			
			// duplicate the read end			
			dup2(pipe2ReadEnd, 0); 
					
			close(pipe2ReadEnd);

			// execute the command
	        execvp(command[0], command);
	
	        // If execution failed
	        fprintf(stderr, "Execution Failed %s ", command[0]);
			perror("");
	        exit(EXIT_FAILURE);
			
		
			
			
		}else{
	        // if it is not first and not last command
	        
	        // close the write end of the pipe 1
			close(pipe1WriteEnd);
			// duplicate stdin and stdout
			dup2(pipe1ReadEnd, 0); 
			dup2(pipe2WriteEnd, 1);
			
			// close the  all ends of the pipes
			close(pipe2WriteEnd);
			close(pipe2ReadEnd);
			close(pipe1ReadEnd);
			

	        // Execute wc
	       	execvp(command[0], command);
	
	        // If execution failed
	        fprintf(stderr, "Execution Failed %s ", command[0]);
			perror("");
	        exit(EXIT_FAILURE);
			 
	    }
    }else{
    	
    	//parent process
    	// handling wait in handlePipeline function
    	
	}

}


// ================ Handle the the command which consists of pipes | =========
void handlePipeline(int numberOfCommands) {
 
 
 	// create the required no. of pipes
    for (int i = 0; i < numberOfCommands-1 ; i++) {
        if (pipe(pipeFileDesc[i]) == -1) {
            perror("Pipe Creation Failed.");
            exit(EXIT_FAILURE);
        }
    }  
    
    // execute commands in pipeline by providing correct input output file descriptors
    
    for (int i = 0; i < numberOfCommands; i++) {		

		//executeIndividualPipeCommand(char * command[MAX_NO_OF_ARGS_ALLOWED],int firstPipeInUse,int firstCommand, int lastCommand,int pipe1ReadEnd,int pipe2ReadEnd,int pipe1WriteEnd,int pipe2WriteEnd)
			
			if(i==0){
				// If it is a first command
			  	executeIndividualPipeCommand(commands[i], 0, i==0 ? 1 : 0, i==numberOfCommands-1? 1 : 0, pipeFileDesc[0][0], pipeFileDesc[1][0], pipeFileDesc[0][1], pipeFileDesc[1][1]);
 			
			}else if(i!=numberOfCommands-1){
				// niether first command nor last command
				executeIndividualPipeCommand(commands[i], i-1, i==0 ? 1 : 0, i==numberOfCommands-1 ? 1 : 0, pipeFileDesc[i-1][0], pipeFileDesc[i][0], pipeFileDesc[i-1][1], pipeFileDesc[i][1]);
				
			}else{
				// last command
				executeIndividualPipeCommand(commands[i], i-2,  i==0 ? 1 : 0, i==numberOfCommands-1 ? 1 : 0, pipeFileDesc[i-2][0], pipeFileDesc[i-1][0], pipeFileDesc[i-2][1], pipeFileDesc[i-1][1]);
			}
    
	}
    // Close pipe file descriptors in the parent process
    for(int i=0;i<numberOfCommands-1;i++){
	    close(pipeFileDesc[i][0]);
	    close(pipeFileDesc[i][1]);
	}
    	
    // wait for all the child
	for (int i = 0; i < numberOfCommands; i++) {
        wait(NULL);
    }
        
    
}


/*
	================================================
	This function handles the execution of command
	along with separating the arguments before executing
	=================================================
*/
int handleArgummentsAndExecuteCommand(char* command) {
	    
    char* fileForInputRedirection = NULL;
    char* fileForOutputRedirection = NULL;
    int isAppendMode = 0;
    char* arguments[MAX_NO_OF_ARGS_ALLOWED];
    int i = 0;

    //tokenize
	char* token = strtok(command, " ");
    
    while (token != NULL ) {
    	
    	// convert ~ to HOME directory path
	    if (token[0] == '~') {
	        char* homeDir = getenv("HOME");
	        if (homeDir != NULL) {
	            char tempPath[MAX_LENGTH_OF_COMMAND];
	            snprintf(tempPath, sizeof(tempPath), "%s%s", homeDir, token + 1);
	            token = tempPath;
	        }
		}	
	    	
        if (strcmp(token, "<") == 0) {
        	
        	// if it is input redirection
            token = strtok(NULL, " ");
            fileForInputRedirection = token;
            
        } else if (strcmp(token, ">") == 0) {
        	
        	// if it is output without append redirection
            token = strtok(NULL, " ");
            fileForOutputRedirection = token;
            isAppendMode = 0;
            
        } else if (strcmp(token, ">>") == 0) {
        	
        	// if it is output with append redirection
            token = strtok(NULL, " ");
            fileForOutputRedirection = token;
            isAppendMode = 1;
            
        } else {
        	// else it is not a file name but a argument of command store it
            arguments[i] = token;
            i++;
        }

        token = strtok(NULL, " ");
    }
    // store  NULL at the end of arguments
    arguments[i] = NULL;


    pid_t childPid = fork();
    if (childPid == 0) {

		// if there is input redirection
        if (fileForInputRedirection != NULL) {
        	// open file
            int inputFileDesc = open(fileForInputRedirection, O_RDONLY);
            
            if (inputFileDesc == -1) {
                perror("Error while opening the input file.");
                exit(EXIT_FAILURE);
            }
            
            // duplicate
            dup2(inputFileDesc, STDIN_FILENO); // STDIN_FILENO =0
            //closing file
            close(inputFileDesc);
        }
		
		// if there is output redirection
        if (fileForOutputRedirection != NULL) {
            int outputFileDesc;
            // if append mode open file in Append mode
            if (isAppendMode)
                outputFileDesc = open(fileForOutputRedirection, O_WRONLY | O_CREAT | O_APPEND, 0666);
            else
            	// else open in write mode only
                outputFileDesc = open(fileForOutputRedirection, O_WRONLY | O_CREAT , 0666);
                
            // if there is error opening file
            if (outputFileDesc == -1) {
                perror("Output Redirection Error");
                exit(EXIT_FAILURE);
            }
            
            dup2(outputFileDesc, STDOUT_FILENO); // STDOUT is 1
            close(outputFileDesc);
        }
        
        
     		
        // Execute the command
        execvp(arguments[0], arguments);

        // execvp only returns if there's an error
        fprintf(stderr, "Execution Failed %s ", arguments[0]);
		perror("");
        exit(EXIT_FAILURE);
        
    } else if (childPid > 0) {
    	
    	// Parent process

       if (runProcessInBg) {
       		// if running in bg donot wait
               return 0;
        }else{
        	// else wait and return the exitstatus
	        int status;
	        waitpid(childPid, &status,0);
	        
	        if (WIFEXITED(status)) {
	            int exitStatus = WEXITSTATUS(status);
	           	return exitStatus;
	        } else {
	            return -1;
	        }
	        return 0;
    	}
        
        
    } else {
        // Error in forking
        perror("Error in forking");
        exit(EXIT_FAILURE);
    }
}



/*
	================================================
	This function handles the execution of command
	where the command array is passed which already
	 have arguments separated
	=================================================
*/

int executeCommandWithoutHandlingArgs(char * command[MAX_NO_OF_ARGS_ALLOWED+1]) {
    
    //fork the child
    pid_t childPid = fork();
    
    if (childPid == 0) {      
     	//in child
		//execute the command
        execvp(command[0], command);
		
		//if error in execvp

        fprintf(stderr, "Execution Failed %s ", command[0]);
		perror("");
        exit(EXIT_FAILURE);
        
        
    } else if (childPid > 0) {
    	// in parent
    	// wait and return the exitstatus
        int status;
        waitpid(childPid, &status,0);
        
        if (WIFEXITED(status)) {
            int exit_status = WEXITSTATUS(status);
           return exit_status;
        } else {
            return -1;
        }
        
        return 0;
        
    } else {
        // Forking error
        perror("Error in forking");
        exit(EXIT_FAILURE);
    }
}

// count the number of arguments in a command
int countNoOfArgs(char * command){
	// count arguments
	
	char duplicateToken[100];
    	
    	strcpy(duplicateToken,command);
    	
		// split based on space for arguments
    	
		char *argumentToken = strtok(duplicateToken, " ");		
		
		// reset arg count
		int	argCount = 0;


		while (argumentToken != NULL) {
		       	
			// handle if no. of given arguments is more than no. of allowed commands 
        	if(argCount>=MAX_NO_OF_ARGS_ALLOWED){
				printf("Maximum number of allowed arguments for any command is %d\n", MAX_NO_OF_ARGS_ALLOWED);
				return -1;	
			}
            argCount++;
	
	        argumentToken = strtok(NULL, " ");
        }
       
	return argCount; 

}

/*
	================================================
	This function splits the command
	based on delimeter but does not split it in to arguments
	=================================================
*/
int splitCommandWithoutArgs(char *input,  char * delim) {
	
	
    int cmdCount = 0;
    char * pt;
    // only input is separated to commands not arguments
    char *token = strtok_r(input, delim, &pt);
    int argCount=0;
    while (token != NULL) {
    	
		// handle if no. of given commands is more than no. of allowed commands
    	if(cmdCount >= MAX_NO_OF_COMMANDS_ALLOWED){
    		printf("Maximum number of allowed commands is %d\n", MAX_NO_OF_COMMANDS_ALLOWED);
			return -1;
		}
	    	
    	commands[cmdCount][0]= token;
    	
    	// check no. of arguments
    	if(countNoOfArgs(token)==-1){
			
			return -1;
			
		}

		// increment cmdcount
        cmdCount++;
        

        
        token = strtok_r(NULL, delim, &pt);
    }


	commands[cmdCount][0]=NULL;
	return 1;

}


/*
	================================================
	This function splits the command
	based on delimeter and also split it in to arguments
	=================================================
*/
int splitCommandWithArgs(char *input,  char * delim) {
    
    //counters for command and arguments
	int cmdCount = 0;
    int argCount=0;
    
    // tokenize
	char *ptr;
    char *token = strtok_r(input, delim, &ptr);
    
    // tokenize till NULL commandCount < no. of commands allowed
    while (token != NULL ) {
    	
    	// handle if no. of given commands is more than no. of allowed commands
    	if(cmdCount >= MAX_NO_OF_COMMANDS_ALLOWED){
    		printf("Maximum number of allowed commands is %d\n", MAX_NO_OF_COMMANDS_ALLOWED);
			return -1;
		}
    	
		// split based on space for arguments
		char *argumentToken = strtok(token, " ");
		
        // reset arg count
		argCount = 0;
        
		//tokenize till the conditions
        while (argumentToken != NULL) {
        	
        	// handle if no. of given arguments is more than no. of allowed commands 
        	if(argCount>=MAX_NO_OF_ARGS_ALLOWED){
				printf("Maximum number of allowed arguments for any command is %d\n", MAX_NO_OF_ARGS_ALLOWED);
				return -1;	
			}
        	// convert ~ to HOME directory path
        	if (argumentToken[0] == '~') {
		        char* homeDir = getenv("HOME");
		        if (homeDir != NULL) {
		            char tempPath[MAX_LENGTH_OF_COMMAND];
		            snprintf(tempPath, sizeof(tempPath), "%s%s", homeDir, argumentToken + 1);
		            argumentToken = tempPath;
		        }
		    }
			
			// store value in commands array
        	
            commands[cmdCount][argCount] = argumentToken;
            argCount++;
            
            argumentToken = strtok(NULL, " ");
        }
        
        // store null at the end of each commmand
        commands[cmdCount][argCount] = NULL;
        
        
        
        cmdCount++;
            
        token = strtok_r(NULL, delim, &ptr);
    }

	

	// store NULL at the last location 
	commands[cmdCount][0]=NULL;
	
	return 1;

}


//================== this is the main function ================= 
int main() {

	int cmdCount=0;
	char inputByUser[MAX_LENGTH_OF_COMMAND];
	char copyOfUserInput[MAX_LENGTH_OF_COMMAND];
	
    while (1) {
    	
    	// printing mshell$ before each input
        printf("mshell$ ");

        // getting user input, from standard input
        fgets(inputByUser, MAX_LENGTH_OF_COMMAND, stdin);
		
        // replaces the \n with NULL character in user input
        inputByUser[strcspn(inputByUser, "\n")] = '\0';
        		

        // creating a copy of inputByUser
        strncpy(copyOfUserInput, inputByUser, MAX_LENGTH_OF_COMMAND);
		
		// Reseting the values
		
		// set running process in background to 0
		runProcessInBg=0;
		
		//empty out the commands array
		commands[0][0]=NULL;
	
		
		// Check if the user input contains both && and ||
		if(strstr(inputByUser, "&&") != NULL && strstr(inputByUser, "||") != NULL){
		
			char* token = strtok(inputByUser, " ");
	        int cmdCount = 0;
	        int argCount=0;
	        char * operators[7];
	        int operator_count=0;
	        int res=0;
	
	        while (token != NULL) {
	        	
	        	// handle if no. of given commands is more than no. of allowed commands
		    	if(cmdCount >= MAX_NO_OF_COMMANDS_ALLOWED){
		    		printf("Maximum number of allowed commands is %d\n", MAX_NO_OF_COMMANDS_ALLOWED);
					res=-1;
					break;
				}
    	
	        	
	        	// spliting input
	        	
	        	// if it is a operator
	        	if(strcmp(token, "&&") == 0 || strcmp(token, "||") == 0){
	        		// store the operator
					operators[operator_count++]=token;
					//store NUll as the last argument
					commands[cmdCount][argCount] = NULL;
					// increase command count
					cmdCount++;
					
					//reset arg count
					argCount=0;
				}else{
					// handle if no. of given commands is more than no. of allowed commands
			    	if(argCount >= MAX_NO_OF_ARGS_ALLOWED){
			    		printf("Maximum number of allowed arguments for any command is %d\n", MAX_NO_OF_ARGS_ALLOWED);
						res=-1;
						break;
					}
					
					// convert ~ to HOME directory path
					if (token[0] == '~') {
				        char* homeDir = getenv("HOME");
				        if (homeDir != NULL) {
				            char tempPath[MAX_LENGTH_OF_COMMAND];
				            snprintf(tempPath, sizeof(tempPath), "%s%s", homeDir, token + 1);
				            token = tempPath;
				        }
				    }
					
					// else it is part of command store it
				 	commands[cmdCount][argCount] = token;
				 	argCount++;
	            	
				}
	           
	
	            token = strtok(NULL, " ");
	        }
	        
	        // for last command
	        commands[cmdCount][argCount] = NULL;
	        cmdCount++;
	        
	        if(res==-1){
				continue;
			}
	        
	        int i = 0;
	        int result = 1; // Result of the previous command (1 = success, 0 = failure)
			// go through all commands
	        while (i < cmdCount) {

	            // Execute the command
	            int res=executeCommandWithoutHandlingArgs(commands[i]);
	
	            // Check the exit status of the command
	            int status;
	            wait(&status);
				
				// if the response is 0 it means exited successfully
	            if (res==0) {
	               	result=1;
	            } else {
	            	// terminated abnormally
	                result = 0; 
	            }
	
	            // Check the  operator 
	            if (i < operator_count) {
	            	
	                if (strcmp(operators[i], "&&") == 0) {
	                    // Operator is '&&'
	                    if (result) {
							// if the previous command successfull execute next command
	                        i++;
	                    } else {
	                    	//if it fails
	                        // Skip the commands until the next '||' is found
	                        while (i < operator_count && strcmp(operators[i], "||") != 0) {
	                            i++;
	                        }
	     					// execute the next command after operator
		                    i++;
	                    }
	                } else if (strcmp(operators[i], "||") == 0) {
	                    // Operator is '||'
	                    if (!result) {
	                    	// if the first command fails
	                        i++;
	                        
	                    } else {
	                    	//if it succeds
	                        // Skip the commands until the next '&&' is found
	                        while (i < operator_count && strcmp(operators[i], "&&") != 0) {
	                        	
	                            i++;
	                        }
	                        
	                       i++;
//	                     
	                    }
	                }
	            }else{
					i++;
				}
	
	        }
		        
		        
		        
		        
		    
		
		
		}else if (strstr(inputByUser, "&&") != NULL) {    // check if user input only contains && operator
			
			// if the command consists of && and not || operator 			

	        int resOfSpliting=splitCommandWithoutArgs(inputByUser, "&&");
			
			// if result of spliting is -1 it means there is some error so do not execute below code
			if(resOfSpliting==-1){
				continue;
			}
	        
		    int i=0; //iterator
	        int result=1;
	        
		     while (commands[i][0] != NULL) {
				
				// execute the command one by one
	            int resOfCommandExecution=handleArgummentsAndExecuteCommand(commands[i][0]);
	            
	            // if resOfCommandExecution is not 0 stop further execution
	            if (resOfCommandExecution!=0) {
	                break;
	            }
	
				// next command
	            i++;
	        }
    
		}else if(strstr(inputByUser, "||") != NULL) {  // check if user input only contains || operator
	        
			int resOfSpliting=splitCommandWithoutArgs(inputByUser, "||");
			
			//if result of spliting is -1 it means there is some error so do not execute below code
			if(resOfSpliting==-1){
				continue;
			}
	        
		    int i=0; //iterator
	        
		    while (commands[i][0] != NULL) {
				
				// execute the command one by one
	            int resOfCommandExecution=handleArgummentsAndExecuteCommand(commands[i][0]);
	            
	            // if resOfCommandExecution is 0 stop further execution
	            if (resOfCommandExecution==0) {
	                break;
	            }
	
	            i++;
	        }
    
		}else if(strchr(inputByUser, '|') !=NULL){  // check if user input only contains | pipe operator
			
			// if the command consists of || and not && operator 
			
			// split command based on |
			int resOfSpliting= splitCommandWithArgs(inputByUser, "|");
	        
	        // if splitting fails stop further processing
	        if(resOfSpliting==-1){
				continue;
			}
	        
	        // calculate the number of commands entered by user separated by  pipe
			int numberOfCommands = 0;
			// iterate till we get NULL
	        while (commands[numberOfCommands][0] != NULL)
	            numberOfCommands++;

			// execute the command as per the pipeline
	        handlePipeline(numberOfCommands);
	        
		}else{
			
			/*
			
				handling ; & and  redirection >, >>, <
			
				if the input contains ; then it will be splitted into different commands 
				else it will be considered as a single command
				here if the redirection operator is given with or without ; it will be handled
				also if there is & for background it will be handled here
				
				
				example 1: ls; pwd; echo hello
				example 2: ls   
				example 3: ./ex1.sh &
				example 4: ls > abc.txt
				example 5: ls > abc.txt ; pwd ; echo hello
							
				
			*/
			
			// token and pointer for spliting
		 	char* token;
        	char* ptr;
        	int cmdCount=0;
        	int res=0;
			// for semicolon , background ,  redirection
	        token = strtok_r(inputByUser, ";", &ptr);
	        while (token != NULL) {
	        	
	        	// handle if no. of given commands is more than no. of allowed commands
		    	if(cmdCount >= MAX_NO_OF_COMMANDS_ALLOWED){
		    		printf("Maximum number of allowed commands is %d\n", MAX_NO_OF_COMMANDS_ALLOWED);
		    		res=-1;
					break;
				}
	
				// if there is & at the last of the input this has to be run in background
	            if (strlen(token) > 0 && token[strlen(token) - 1] == '&') {
	                runProcessInBg = 1;
	                // remove & symbol from input
	                token[strlen(token) - 1] = '\0';
	            }
	            // store commands
				commands[cmdCount][0]=token;
				
				
				char * val;
				
				int firstPartLength;
				
				if ((val=strstr(token, "<")) != NULL) {
        			
        			firstPartLength = val - token;

			        // create temp arry for firstpart
			        char firstPart[firstPartLength + 1];

			        // Copy the first part
			        strncpy(firstPart, token, firstPartLength);
        			
        			// check no. of arguments
		        	if(countNoOfArgs(firstPart)==-1){
						res=-1;
					}
		            
		        } else if ((val=strstr(token, ">"))!=NULL) {
		        	
					firstPartLength = val - token;

			        // create temp arry for firstpart
			        char firstPart[firstPartLength + 1];

			        // Copy the first part
			        strncpy(firstPart, token, firstPartLength);
			        
        			// check no. of arguments
		        	if(countNoOfArgs(firstPart)==-1){
						res=-1;
					}
		        	
		        	
		            
		        } else if ((val=strstr(token, ">>"))!=NULL) {
		        	
		        	firstPartLength = val - token;

			        // create temp arry for firstpart
			        char firstPart[firstPartLength + 1];

			        // Copy the first part
			        strncpy(firstPart, token, firstPartLength);
        			// check no. of arguments
		        	if(countNoOfArgs(firstPart)==-1){
						res=-1;
					}
		        } else {
			        
					// check no. of arguments
			    	if(countNoOfArgs(token)==-1){
						res=-1;
					}
				}
				
	            cmdCount++;
	            token = strtok_r(NULL, ";", &ptr);
	        }
	        
	        commands[cmdCount][0]=NULL;
	        if(res==-1){
				continue;
			}
	        
	        cmdCount=0;
	        while(commands[cmdCount][0]!=NULL){
				// execute the command
	            handleArgummentsAndExecuteCommand(commands[cmdCount][0]);
	            cmdCount++;
			}
	        	    
    }

}

    return 0;
}

