#include<stdio.h>

int main(){
	
	int i;
	
	while(1){
		i=(i+1)%500;
	}
	
	return 0;
}
