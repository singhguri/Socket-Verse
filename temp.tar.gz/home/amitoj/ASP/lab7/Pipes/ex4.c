#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
 
 //equivalent of $ls|wc -w 
 
int main(int argc, char *argv[]){
int fd[2];

if(pipe(fd)==-1) exit(1);

	if(fork() == 0){
		//child
		int fd2[2];
		
		if(pipe(fd2)==-1) exit(1);
		
		if(fork()>0){
			
			
			close(fd[1]);
			dup2(fd[0], 0); // 0 is the standard input
			dup2(fd2[1], 1); // 1is the standard opt
	//		
			close(fd2[1]);
			close(fd[0]); // close original file descriptor
			execlp("wc", "wc", "-c", NULL);
				
				//first child and a parent
		
		
		}else{
	
			close(fd[0]);
			close(fd[1]); // close original file descriptor
			close(fd2[1]);
			
			dup2(fd2[0], 0); // 0 is the standard input
//						
			close(fd2[0]);
////			close(fd[1]);
			execlp("wc", "wc", "-w",NULL);
			
			
			//child child
		}
				
	}
	else {
		
		//parent
		
			close(fd[0]);
			
			dup2(fd[1], 1); // 1 is the standard output
			close(fd[1]); // close original file descriptor
			
			execlp("ls", "ls", NULL);
		
	
	}
}//End main


