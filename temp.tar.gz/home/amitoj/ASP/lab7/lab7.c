#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    int pipe_fd[2];
    pid_t pid1, pid2;

    // Create a pipe
    if (pipe(pipe_fd) == -1) {
        perror("pipe failed");
        exit(EXIT_FAILURE);
    }

    // Fork the first child process (ls)
    pid1 = fork();
    if (pid1 == -1) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    } else if (pid1 == 0) {
        // Child process (ls)
        // Set up pipe redirection
        dup2(pipe_fd[1], STDOUT_FILENO);
        close(pipe_fd[0]);
        close(pipe_fd[1]);

        // Execute ls
        execlp("ls", "ls", NULL);

        // If execlp fails, print an error
        perror("execlp ls failed");
        exit(EXIT_FAILURE);
    }

    // Fork the second child process (wc)
    pid2 = fork();
    if (pid2 == -1) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    } else if (pid2 == 0) {
        // Child process (wc)
        // Set up pipe redirection
        dup2(pipe_fd[0], STDIN_FILENO);
        close(pipe_fd[0]);
        close(pipe_fd[1]);

        // Execute wc
        execlp("wc", "wc", NULL);

        // If execlp fails, print an error
        perror("execlp wc failed");
        exit(EXIT_FAILURE);
    }

    // Close pipe file descriptors in the parent process
    close(pipe_fd[0]);
    close(pipe_fd[1]);

    // Wait for the second child process (wc) to complete
    waitpid(pid2, NULL, 0);

    return 0;
}

