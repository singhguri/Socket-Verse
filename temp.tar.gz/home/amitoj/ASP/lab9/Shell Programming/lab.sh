#!/bin/bash

file="./sample.txt"
if [ ! -e $file ]; then #File does not exist
	# create it
	touch $file
	echo "File created"
elif [ -O $file ]; then #you are the owner
	
	
	if [ -w $file ]; then #have write permission
		ls -1 >> $file
	else
		echo "you dont have write permission"
		chmod u+w $file # give write permission to file
		echo "write permission granted"
	fi
else # file xist but you are not owner
	echo "File exist but you are not the owner"
fi