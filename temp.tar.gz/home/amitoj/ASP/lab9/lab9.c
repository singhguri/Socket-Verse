// Amitoj Singh Ahuja
//110094594
// Sec 2

#include <sys/types.h>
#include <unistd.h>
#include <pthread.h>
#include <stdio.h>


int main(){

	return 0;
}
  
