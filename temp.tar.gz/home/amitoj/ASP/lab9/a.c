#include<stdio.h>

int main(){

	int p1,p2,p3,p4;
	
	p1=fork();
p2=fork();
p3=fork();
p4=fork();
if(p1==0 || !p3 || !p2 || !p4){
	for(;;) sleep(1);
}else 
	sleep(10);
//	setpgid(p2,getppid());
	kill(0,9);
	while(1) sleep(1);

	return 0;
}
