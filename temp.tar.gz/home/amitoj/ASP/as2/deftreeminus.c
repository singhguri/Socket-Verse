/*

Name: Amitoj Singh Ahuja
Section 2 ,Tue 8:30 - 11:20
Student Id: 110094594

*/

// this is required for nftw
#define _XOPEN_SOURCE 500 

#include <sys/stat.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdio.h>
#include <ftw.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <limits.h>
#include <strings.h>
#include <stdlib.h>
#include <unistd.h>
#include <libgen.h>
#include <time.h>
#include <sys/signal.h>
#include <dirent.h>


#define DIRCODE 4
#define MAXPROCESSES 100000

// Global variables put in a struct
struct CommonAttributes {
	
	pid_t rootProcessId;
	int noOfProcessIdsToBeKilled;
	pid_t processIdsToBeKilled[MAXPROCESSES];
	pid_t parentIdOfPID1;
	char option;
	pid_t processNotTobeKilled;
	pid_t BashPID;
	int optionValue;

} CommonAttributes;

/* 
	this function checks if processPid is descendant of ancestorPid or not 
 	and also store parent Pid of processPid in parentPid
*/




bool isDescendant(pid_t processPid, pid_t ancestorPid,pid_t *parentPid) {
	
    char procPath[PATH_MAX];
    pid_t pid = processPid;
    
    // This returns true when it matches to itself.
	if(processPid == ancestorPid) return true;
	
    while (pid !=0) {
        // Creating and Storing path in procPath of the status file of a process
        snprintf(procPath, sizeof(procPath), "/proc/%d/status", pid);

        // Open the status file
        FILE *statusFile = fopen(procPath, "r");
        if (statusFile == NULL) {
			// incase file is not openeed
            return false;
        }

        // Read the PPID from the status file
        char line[150];
        int ppid = -1;
        while (fgets(line, sizeof(line), statusFile) != NULL) {
            if (sscanf(line, "PPid: %d", &ppid) == 1) //stores the ppid to ppid variable
                break;
        }
		
		//close the file
        fclose(statusFile);

		// if parentPid was not having any value
		if(*parentPid==0) *parentPid=ppid;
		
        // Check if the PPID matches the ancestor's PID
        if (ppid == ancestorPid)
            return true;

        // Repeat this process for parentId
        pid = ppid;
    }

    return false;
}


/*
	This function returns the status of process in single char (Sleep, Zombie etc.)
*/
char  getState(pid_t processId){

	char procPath[PATH_MAX];
    pid_t pid = processId;

    // Create the path for the current process's status file in /proc
    snprintf(procPath, sizeof(procPath), "/proc/%d/status", pid);

    // Opening the status file
    FILE *statusFile = fopen(procPath, "r");
    if (statusFile == NULL) {
		// In case it was not possible to open the file
        return false;
    }

    // Read the PPID from the status file
    char cstate; 
    char line[150];
    while (fgets(line, sizeof(line), statusFile) != NULL) {
        if (sscanf(line, "State: %c", &cstate) == 1) //reading only the character instea of whole eg: State: z (zombie)
            break;
    }

	//closingg the file
    fclose(statusFile);

		

    return cstate;

}

/*
	This function returns the parent Id of a process
*/

pid_t getParentId(pid_t processId){
	
	char procPath[PATH_MAX];
    pid_t pid = processId;
    
	// Creating and Storing path in procPath of the status file of a process
    snprintf(procPath, sizeof(procPath), "/proc/%d/status", pid);

    // Open the status file
    FILE *statusFile = fopen(procPath, "r");
    if (statusFile == NULL) {
		//	Incase it is not possible to open the file
        return false;
    }

    // Read the PPID from the status file
    char line[150];
    int ppid = -1;
    //traverse the file line by line
    while (fgets(line, sizeof(line), statusFile) != NULL) {
    	// get and stores PPID in ppid variable
        if (sscanf(line, "PPid: %d", &ppid) == 1)
            break;
    }

	//close the file
    fclose(statusFile);


    return ppid;

}

/*
	This function is resposible for killing the processes
	from the array of processes that to be killed.
*/

int killProcesses(){
	
	// traverse the array of processes to be killed
	for(int i=0;i<CommonAttributes.noOfProcessIdsToBeKilled;i++){
		
		pid_t processId=CommonAttributes.processIdsToBeKilled[i];
		
		/// this checks if the process is not equal to the one not to be killed and then call kill system call.
		if (processId!= CommonAttributes.processNotTobeKilled && kill(processId, SIGKILL) == -1) {
			if (errno == ESRCH) {
				//process doesnot exist or has already been killed
			}else{
		        printf("Kill failed for %d\n",processId);
			}
	    }
	}
	
}



/*
	This function returns the no. of defunct child under a PID
*/
int countDefunctChild(pid_t pid){

	pid_t ParentPID=pid;
	int count=0;
	
	DIR *openingDir;
    struct dirent *direntry;
    
	const char *procPath="/proc";
    openingDir = opendir(procPath);
    if (openingDir == NULL) {

        perror("opendir() failed");
        return 0;
    }

    // Iterate over the entries in the directory
    while ((direntry = readdir(openingDir)) != NULL) {
    	
        // skip current and parent directory i.e. '.' and '..'
        if (strcmp(direntry->d_name, ".") == 0 || strcmp(direntry->d_name, "..") == 0)
            continue;

      
        // create and store full path to  direntryPath
        char direntryPath[PATH_MAX];
        snprintf(direntryPath, sizeof(direntryPath), "%s/%s", procPath, direntry->d_name);

		// checks entry is of directory type
        if (direntry->d_type==DIRCODE) {
        	
        	// It checks if the directory is of process
        	if (direntry->d_name[0]>='0' && direntry->d_name[0]<='9') {
        		
           		pid_t currentPid=atoi(direntry->d_name);
        	
        		// if the entry is child of process id and is defucnt 
        		if(getParentId(currentPid)== ParentPID && getState(currentPid)=='Z'){
        			//increase count
					count++;
				}
            
	        }else{
				continue;
			}
		}else{
			continue;
		}
    }
	// close dir
    closedir(openingDir);

	return count;


}


/*
	This function returns the elapsed time of the process
*/
int getElapsedTime(pid_t processId){
	

	pid_t pid=processId;
	
	char statFilePath[PATH_MAX];
	// creates and stores path of stat file in statFilePath
    snprintf(statFilePath, sizeof(statFilePath), "/proc/%d/stat", pid);

    // Open the stat file in read mode
    FILE *file = fopen(statFilePath, "r");
    if (file == NULL) {
        perror("Error Opening stat file.");
        return 0;
    }

    // Read the contents of the stat file
    char statBuffer[1500];
    
	// read content of file
    if (fgets(statBuffer, sizeof(statBuffer), file) == NULL) {
        perror("Error reading content of file.");
        //close file
        fclose(file);
        return 0;
    }

	//close file
    fclose(file);
    
    
    // Extract the start time from the stat buffer
    
    unsigned long startTime = 0;
    // split stat buffer in to differnt string at a space " "
    char *token = strtok(statBuffer, " "); 
    int tokenCount = 1; 
    while (token != NULL) {
    	// start time of process is the 22 position
        if (tokenCount == 22) {
        	// store from token converting it from string to unsigned long
            startTime = strtoul(token, NULL, 10);
            break;
        }
        //  else go to next token
        token = strtok(NULL, " ");
        tokenCount++;
    }



 	// Open the uptime of system from /proc/uptime
    file = fopen("/proc/uptime", "r");
    if (file == NULL) {
        perror("Error opening uptime file.");
        return 0;
    }

    // Read the contents of the uptime file
    char uptimeBuffer[1024];
    
    if (fgets(uptimeBuffer, sizeof(uptimeBuffer), file) == NULL) {
        perror("Error reading uptime file content.");
        fclose(file);
        return 0;
    }
    
	//close file
    fclose(file);
    
    
    unsigned long uptime=0;
    token = strtok(uptimeBuffer, " ");  // Split the uptimebuffer into tokens at " "
    tokenCount = 1; 
	
	// uptime is stored at first position
    if (tokenCount == 1) {
    	// store from converting it from string to unsigned long
        uptime = strtoul(token, NULL, 10); 
    }

	// elapsed time = uptime - starttime(in seconds)
	// starttime stored in stat file is in cpu ticks
	// to convert it to in seconds divide it by sysconf(_SC_CLK_TCK)
	unsigned long elapsedTime = (unsigned long)((uptime- (startTime/ sysconf(_SC_CLK_TCK)) ));

    return (int) elapsedTime/60; // convert to minutes and return

}



/*
	Traverse proc directory and execute base don options
*/

int traverseProcessDirectory(const char *filePath, const struct stat *statbuf, int flagType, struct FTW *ftwbuffer) {
     
	
	if (flagType == FTW_D) {
		
		if (ftwbuffer->level > 1) {
        	return 0;  
    	} 
		
		// get only the directory name
        // ftwbuffer->base is offset of base path which skips the base path and only gives dir name
        const char *dirName = filePath + ftwbuffer->base ;
       	
        if (dirName != NULL) {
        	// check the next character after '/'  
            if (dirName[0]>='0' && dirName[0]<='9') {
                                    
	           	pid_t parentPid=0;
	           	pid_t currentPid=atoi(dirName);
	           	
	           	// we donot want to delete init or other pid less than that so return here.
	           	if(currentPid<=1) return 0;
	           	
				pid_t rootPid=CommonAttributes.rootProcessId;
				
				/*
					when no option provided
					check the current process is descendant of root process
					if current pid is a zombie process
				
				*/
	        	if (CommonAttributes.option=='\0' && isDescendant(currentPid,rootPid ,&parentPid) && getState(currentPid)=='Z'){
	        		
	        		// if parent is not init and parent is not current BASH PID
					if(parentPid>1 && parentPid!=CommonAttributes.BashPID){
						
						// store the parent in array of processes to be killed.
				 		CommonAttributes.processIdsToBeKilled[CommonAttributes.noOfProcessIdsToBeKilled]=parentPid;
		        		CommonAttributes.noOfProcessIdsToBeKilled++;
	        		}
	        		
				}

				/*
					else if option is -b and current process is descendant of root and
					its no. of defunct child are greater than the value provided in arguments
				*/				
				else if(CommonAttributes.option=='b' && isDescendant(currentPid,rootPid ,&parentPid) &&
						countDefunctChild(currentPid) >=CommonAttributes.optionValue){		 	
				 	
				 	// it is not init and not bash process
					if(currentPid>1 && currentPid!=CommonAttributes.BashPID){
						
						//	store the current process to array of processes to be killed						        
				 		CommonAttributes.processIdsToBeKilled[CommonAttributes.noOfProcessIdsToBeKilled]=currentPid;
		        		CommonAttributes.noOfProcessIdsToBeKilled++;
	        		}
	        		
				}
				/*
					else if option is -t and current process is descendant of root and
					its no. of defunct child are greater than 0 and elapsed time of current process is grater than
					provide in arguments.
				*/
				else if(CommonAttributes.option=='t' && isDescendant(currentPid,rootPid ,&parentPid) &&
					getElapsedTime(currentPid) >=CommonAttributes.optionValue && countDefunctChild(currentPid)>0){
					
					// it is not init or bash process
					if(currentPid>1 && currentPid!=CommonAttributes.BashPID){
						
						//	store the current process to array of processes to be killed
						CommonAttributes.processIdsToBeKilled[CommonAttributes.noOfProcessIdsToBeKilled]=currentPid;
			        	CommonAttributes.noOfProcessIdsToBeKilled++;
					}
						
				}
					
		        		
	        	       	
            }
        }
    }
    return 0;
}


// This function is the main function that gets called from main func.
void executeOperation(){
	
	//traverse on all the processes in /proc directory
	if ( nftw("/proc", traverseProcessDirectory, 10, FTW_PHYS)== -1) {
        perror("Failed to traverse /proc directory.\n");
        exit(EXIT_FAILURE);
    }
    
    // During traversal processes to be killed are stored in an array
    // Call kill processes function
	
	killProcesses();
}



int main(int argc, char *argv[]) {
	
	char * commandFormat="deftreeminus [root_process] [OPTION1] [OPTION Value] [-processid]";
	if(argc<2){// error 
		printf("Very few arguments\n Command Format: %s\n",commandFormat);
		exit(0);
	}
	
	
  	CommonAttributes.option='\0';
  	CommonAttributes.optionValue=INT_MAX;
  	CommonAttributes.BashPID=getppid(); //store the bash pid
	CommonAttributes.rootProcessId=(pid_t)atoi(argv[1]); 	//get root pid
	CommonAttributes.noOfProcessIdsToBeKilled=0; //number of processes to be killed
	CommonAttributes.processNotTobeKilled=-1; // process not to be killed
	

	
	if(argv[argc-1][0]=='-' && argv[argc-1][1]>='0' && argv[argc-1][1]<='9'){
		//this means that this is a process id which should not be killed
		// store it in processNotTobeKilled
		CommonAttributes.processNotTobeKilled=atoi(argv[argc-1]+1);
	}
	
	// if arguments grater than 3 and option is -b
	if( argc>=3 && argv[2][0]=='-' && argv[2][1]=='b' ){
		
		//store the option char
		CommonAttributes.option=(argv[2][1]);
			
		// store the option value	
		CommonAttributes.optionValue=atoi(argv[3]);
				
	
	}else if( argc >=3 && argv[2][0]=='-' && argv[2][1]=='t'){
		// if arguments grater than 3 and option is -t
		
		//store the option char
		CommonAttributes.option=(argv[2][1]);
			
		// store the option value	
		CommonAttributes.optionValue=atoi(argv[3]);
	}else{
		if(argc==2 || (argc==3 && CommonAttributes.processNotTobeKilled!=-1)){
		
		}else{
			perror("Wrong command format\n");
			printf("Command format should be %s\n",commandFormat);
			exit(0);
		}	
	}

	// this is the main function handling the execution
	executeOperation();
	


	
    return 0;
}

