 #define _XOPEN_SOURCE 500
       #include <ftw.h>
       #include <stdio.h>
       #include <stdlib.h>
       #include <string.h>
       #include <stdint.h>
       #include <dirent.h>

      
       int main(int argc, char *argv[])
       {
       	DIR *dir;
    struct dirent *entry;
	const char *path="/proc";
          dir = opendir(path);
    if (dir == NULL) {
    		printf("in counr rrr %d\n ",getpid());
        perror("opendir() failed");
        return 0;
    }
       }
