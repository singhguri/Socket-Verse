/*

Name: Amitoj Singh Ahuja
Section 2 ,Tue 8:30 - 11:20
Student Id: 110094594

*/

// this is required for nftw
#define _XOPEN_SOURCE 500 

#include <ftw.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdint.h>
#include <limits.h>
#include <fcntl.h>
#include <sys/types.h>
#include <stdbool.h>
#include <errno.h>
#include <string.h>
#include <strings.h>
#include <libgen.h>
#include <sys/stat.h>



/// these are varibles globally available encapsulated in a struct
struct CommonAttributes {
	
	pid_t rootProcessId;
	int noOfProcessIds;
	pid_t * processIds;
	pid_t parentIdOfPID1;
	char * option;

} CommonAttributes;



/* 
	this function checks if processPid is descendant of ancestorPid or not 
 	and also store parent Pid of processPid in parentPid
*/

bool isDescendant(pid_t processPid, pid_t ancestorPid,pid_t *parentPid) {
    char procPath[PATH_MAX];
    pid_t pid = processPid;
	
    while (pid !=0) {
        // Creating and Storing path in procPath of the status file of a process
        snprintf(procPath, sizeof(procPath), "/proc/%d/status", pid);

        // Open the status file
        FILE *statusFile = fopen(procPath, "r");
        if (statusFile == NULL) {
			// incase file is not openeed
            return false;
        }

        // Read the PPID from the status file
        char line[150];
        int ppid = -1;
        while (fgets(line, sizeof(line), statusFile) != NULL) {
            if (sscanf(line, "PPid: %d", &ppid) == 1) //stores the ppid to ppid variable
                break;
        }
		
		//close the file
        fclose(statusFile);

		// if parentPid was not having any value
		if(*parentPid==0) *parentPid=ppid;
		
        // Check if the PPID matches the ancestor's PID
        if (ppid == ancestorPid)
            return true;

        // Repeat this process for parentId
        pid = ppid;
    }

    return false;
}


/*
	This is the main function for prcinfo which always run
*/
void checkForDescendants(){
	
	// traverse through all the process given in arguments
	for(int i=0;i<CommonAttributes.noOfProcessIds;i++){
		pid_t parentPid=0;
		
		// If the process is descendant of root process print its PID and PPID
		if (isDescendant(CommonAttributes.processIds[i], CommonAttributes.rootProcessId,&parentPid))
        	printf("%d %d\n", CommonAttributes.processIds[i], parentPid);
				
	}


}

/*
	This function returns the status of process in single char (Sleep, Zombie etc.)
*/
char  getState(pid_t processId){

	char procPath[PATH_MAX];
    pid_t pid = processId;

    // Create the path for the current process's status file in /proc
    snprintf(procPath, sizeof(procPath), "/proc/%d/status", pid);

    // Opening the status file
    FILE *statusFile = fopen(procPath, "r");
    if (statusFile == NULL) {
		// In case it was not possible to open the file
        return false;
    }

        // Read the PPID from the status file
        char cstate = '\0'; 
        char line[150];
        while (fgets(line, sizeof(line), statusFile) != NULL) {
            if (sscanf(line, "State: %c", &cstate) == 1) //reading only the character instea of whole eg: State: z (zombie)
                break;
        }

		//closingg the file
        fclose(statusFile);

		

    return cstate;


}

/*
	This function returns the parent Id of a process
*/

pid_t getParentId(pid_t processId){
	
	char procPath[PATH_MAX];
    pid_t pid = processId;
    
	// Creating and Storing path in procPath of the status file of a process
    snprintf(procPath, sizeof(procPath), "/proc/%d/status", pid);

    // Open the status file
    FILE *statusFile = fopen(procPath, "r");
    if (statusFile == NULL) {
		//	Incase it is not possible to open the file
        return false;
    }

    // Read the PPID from the status file
    char line[150];
    int ppid = -1;
    //traverse the file line by line
    while (fgets(line, sizeof(line), statusFile) != NULL) {
    	// get and stores PPID in ppid variable
        if (sscanf(line, "PPid: %d", &ppid) == 1)
            break;
    }

	//close the file
    fclose(statusFile);


    return ppid;

}

/*
	Traverse process directory
*/

int traverseProcessDirectory(const char *filePath, const struct stat *statbuf, int flagType, struct FTW *ftwbuffer) {
 
	// concerned about directories only
	if (flagType == FTW_D) {

		// only traversal of /proc is required not sub directories
		if (ftwbuffer->level > 1) {
        	return 0;  
    	}
    	
    	
        // get only the directory name
        // ftwbuffer->base is offset of base path which skips the base path and only gives dir name
        const char *dirName = filePath + ftwbuffer->base ;
       	
        if (dirName != NULL) {
           
            if (dirName[0]>='0' && dirName[0]<='9') { 
            
                //if they are digits it is a process directory
                                
	           	pid_t parentPid=0;
	           	pid_t currentPid=atoi(dirName); // convert string to int
	           	
	           	if(currentPid<=1) return 0; // if it is less or equal to 1 we dont go further
	           	
	           	
	           	// as we have to find all the things for process_id1
				pid_t firstPid=CommonAttributes.processIds[0];
				
				// get the parent ID of  process in which we are
				pid_t parentOfCurrent=getParentId(currentPid);
				
				
				//execute according to the option provided.
				
				if(strcmp("-nd",CommonAttributes.option)==0){
					
					
					 //////////// for -nd  non direct descendants
					 /**
						process is descendant of first process and 
						parentPid of the current process is not equal to first process id
					**/
					if (isDescendant(currentPid,firstPid ,&parentPid) && parentPid!=firstPid)
	        				printf("%d\n", currentPid);
	        			
	        	}else if(strcmp("-dd",CommonAttributes.option)==0){	
	        	
	        		////////// for -dd direct descendants
	        		
	        		/**
						process is descendant of first process and 
						parentPid of the current process is equal to first process id
					**/
	        		
		        	if (isDescendant(currentPid,firstPid ,&parentPid) && parentPid==firstPid)
		        		printf("%d\n", currentPid);
		        			
	        	}else if(strcmp("-sb",CommonAttributes.option)==0){
	        		
					//////////// for -sb siblings of  first id
					/**
						parent of first process and current process is same 
						also current process is not equal to first process
					**/
					if ( currentPid!=firstPid && parentOfCurrent==CommonAttributes.parentIdOfPID1)
	        			printf("%d\n", currentPid);
	        			
	        	}else if(strcmp("-sz",CommonAttributes.option)==0){
	        	
		        	//////  for -sz defunct siblings of  first id
		        	/**
						parent of first process and current process is same 
						also current process is not equal to first process
						and current process state is zombie.
					**/
		        	
		        	if ( currentPid!=firstPid && parentOfCurrent==CommonAttributes.parentIdOfPID1 && getState(currentPid)=='Z')
		        		printf("%d\n", currentPid);
		        			
		    	}else if(strcmp("-gc",CommonAttributes.option)==0){
	        	
		        	/////////// - gc additionally lists the PIDs of all the grandchildren of process_id1
		        	
		        	/**
						parent of current process's parent is equal to first process 
						also current process is not equal to first process
					**/
		        	        	
		        	pid_t gPid=getParentId(parentOfCurrent);
		        	
		        	if(currentPid!=firstPid && gPid==firstPid)
						printf("%d\n", currentPid);
					
				
				}else if(strcmp("-zc",CommonAttributes.option)==0){
				
					////////// for -zc direct descendants of pid1 and defunct
					
					/**
						process is descendant of first process and 
						parentPid of the current process is equal to first process id
						and current process is in zombie state.
					**/
		        	if (isDescendant(currentPid,firstPid ,&parentPid) && parentPid==firstPid && getState(currentPid)=='Z')
		        		printf("%d\n", currentPid);
		        		
	        	}
	        	       	
            }
        }
    }
    return 0;
}


/*
	This function is called from main to handle the options
*/
void resultOfOption(){
	
	
	if(strcmp("-zz",CommonAttributes.option)==0){
					
		/////////// -zz status of pid1
		
		char stateOfPid1=getState(CommonAttributes.processIds[0]);
		
		if(stateOfPid1=='Z'){
			printf("DEFUNCT\n");
		}else{
			printf("NOT DEFUNCT\n");
		}
	}else{
		
		//traverse on all the processes in /proc directory
		if ( nftw("/proc", traverseProcessDirectory,10,  FTW_PHYS)== -1) {
	        perror("Failed to traverse /proc directory.\n");
	        exit(EXIT_FAILURE);
	    }
	}


}


int main(int argc, char *argv[]) {
	
	
	char * commandFormat="prcinfo [root_process] [processId1] [processId2] ... [processId 5] [-option]";
	if(argc<3){// error 
		printf("Very few arguments\n Command Format: %s\n",commandFormat);
		exit(0);
	}
  	CommonAttributes.option=NULL;
	
	// Stores the root process Id after converting it to integer
	CommonAttributes.rootProcessId=(pid_t)atoi(argv[1]);
	
	// stores no. of process Ids as (total argument count- 2 (program name + root process id))
	CommonAttributes.noOfProcessIds= argc-2;
	
	// incase we have an option provided store it and reduce no. of process
	if(argv[argc-1][0]=='-'){
		CommonAttributes.option=argv[argc-1];
		CommonAttributes.noOfProcessIds--;
	}

	// create a array with required space to store all process ids
	CommonAttributes.processIds= (pid_t*)malloc(CommonAttributes.noOfProcessIds * sizeof(int));
	

	// AS maximum of 5 process can be provided, incase of more than 5, they will be dropped.
	CommonAttributes.noOfProcessIds = CommonAttributes.noOfProcessIds > 5 ? 5 : CommonAttributes.noOfProcessIds;
		
	//insert process ids in array.
	for(int i=0;i<CommonAttributes.noOfProcessIds;i++){
		CommonAttributes.processIds[i]=(pid_t)atoi(argv[2+i]);
	}
	
	// get parent of first pid
	CommonAttributes.parentIdOfPID1=getParentId(CommonAttributes.processIds[0]);
	
	// Display this this always, main prcinfo function
	checkForDescendants();
	
	if(CommonAttributes.option==NULL){
		// does not have option
		//pass
		
	}else if(strcmp("-nd",CommonAttributes.option)==0 || strcmp("-dd",CommonAttributes.option)==0 
	|| strcmp("-sb",CommonAttributes.option)==0 || strcmp("-sz",CommonAttributes.option)==0
	||	strcmp("-gc",CommonAttributes.option)==0 || strcmp("-zz",CommonAttributes.option)==0 
	|| strcmp("-zc",CommonAttributes.option)==0 ){
		// in case option is one of them 		
		resultOfOption();
		
	}else{
		//else wrong option
		printf("\nWrong option provided.\n");
	}
    
    return 0;
}

