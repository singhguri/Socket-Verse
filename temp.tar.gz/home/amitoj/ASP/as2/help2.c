
// C program to demonstrate waitpid()
#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>
#include<unistd.h>
 

 

int main()
{	
	
	int p1=fork();
	int p2= fork();
	int p3=fork();
	
	
	if(p1==0 || p2==0 ||p3==0){
		exit(0);
		
	}
    else{
		for(;;) sleep(1);
		
		}
}
