#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include<sys/wait.h>
#include<string.h>
 
 
 
int main(void) {
  
  //forking 
  umask(0000);
  int mi=getppid();
  int f1= fork();
  int f2=fork();
  char *lab4path="/home/amitoj/lab4";
  char *programName = "/bin/ls";
  
	//this is grand child if its parent pid is equal to f1
	if(f1 > 0 && f2 > 0)
    {
       

//parent
		
	}
	else if(f1==0 && f2>0 ){
		
			
  		
  		//for f1
  		
  		//waiting for grandchild
  		int stat;
		//Parent Process 
	    int k=wait(&stat); 
	    	// checking the status
    	if (WIFEXITED(stat)){
            printf("Child process, value of wait %d ,  normally terminated with status: %d\n",
                   k, WEXITSTATUS(stat)); //Termination code of the child process that terminated normally
        	
        	//when terminated normally
        	
        	printf("Contents of /home/amitoj/lab4: \n");
		 	char *args[] = {programName, "/home/amitoj/lab4", NULL};
		 
		  	execv(programName, args);
				
		}
		
		printf("GID: f1: %d\n",getpgrp());
                   
    	if (WIFSIGNALED(stat))
            printf("Child process value of wait %d , abnormally terminated with status: %d\n",
                   k, WTERMSIG(stat)); //Signal that casused the termination 
                   
  		
	
	  	
  	}else if(f2==0 && f1>0){
  		
  		
  		
  		
  		printf("GID: f2: %d\n",getpgrp());
  		
	  		//here f2 will be c2;
		// ls -1 /home/username
	  	
	  	char *arg1 = "-1";
	  	//change username(amitoj) with your username
	  	char *arg2= "/home/amitoj";
	
	 
	  	execl(programName, programName, arg1,arg2, NULL);
	  
  	}else{
  		
  		printf("GID: gc: %d\n",getpgrp());
	  		//grandchild
			printf("\n\n\n\nin gc\n\n");
			
			  char *lab4path1="/home/amitoj/lab4";
			chdir(lab4path1);
			
			//open the file	
			int fd1=open("sample.txt",O_CREAT|O_RDWR,0777);
			
			if(fd1==-1){
				printf("Some error occured\n");
				exit(0);
			}

	}
  
  
  
  
  
 
  return 0;
}
