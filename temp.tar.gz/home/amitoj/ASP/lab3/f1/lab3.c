#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include<sys/wait.h>
#include<string.h>
 

int main(){

	//creating three variables
	int num1=10, num2=20, num3=30;
	
	//creating sample.txt
	int fd=open("sample.txt",O_CREAT|O_RDWR,0777);
	
	if(fd==-1){
		printf("Some error occured\n");
		exit(0);
	}
	
	//invoking 2 consecutive fork calls
	int pid1=fork();
	int pid2=fork();
	
	int stat;
	
	long int n;
	char s[]="COMP 8567";
	int sizeOfString=strlen(s);
	
	// error for fork
	if(pid1==-1 || pid2==-1){
		printf("Some error occured while forking\n");
		close(fd);

		
	}else if(pid1==0 || pid2==0)
    {
    	// writing
    	n= write(fd,s,sizeOfString);
    	for(int i=0;i<15;i++){
			printf("PID: %d , PPID: %d\n", getpid(),getppid());
			sleep(1);
		}

		num1+=10;
		num2+=10;
		num3+=10;
		
		printf("num1: %d, num2: %d, num3: %d\n", num1,num2,num3);

    }
    else
    {
	    //Parent Process 
	    int k=wait(&stat); 
	    	// checking the status
    	if (WIFEXITED(stat))
            printf("Child process, value of wait %d ,  normally terminated with status: %d\n",
                   k, WEXITSTATUS(stat)); //Termination code of the child process that terminated normally
                   
    	if (WIFSIGNALED(stat))
            printf("Child process value of wait %d , abnormally terminated with status: %d\n",
                   k, WTERMSIG(stat)); //Signal that casused the termination 
                   
	    
		// writing to the file
	    char *s1="HELLO! FROM PARENT";
		sizeOfString=strlen(s1);
	    n= write(fd,s1,sizeOfString);
	                   
		close(fd);
		
		//iincrement
		
		num1+=25;
		num2+=25;
		num3+=25;
		
		//printing
		printf("num1: %d, num2: %d, num3: %d\n", num1,num2,num3);
	                   
   //Parent Process 
	  k=wait(&stat); 
    
    	// checking the status
    	if (WIFEXITED(stat))
            printf("Child process, value of wait %d ,  normally terminated with status: %d\n",
                   k, WEXITSTATUS(stat)); //Termination code of the child process that terminated normally
                   
    	if (WIFSIGNALED(stat))
            printf("Child process value of wait %d , abnormally terminated with status: %d\n",
                   k, WTERMSIG(stat)); //Signal that casused the termination 
                   
    
    
    
    } 
    	


	return 0;
}
