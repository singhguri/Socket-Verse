/*

Name: Amitoj Singh Ahuja
Section 2 ,Tue 8:30 - 11:20
Student Id: 110094594
*/

#include <stdio.h>
#include <sys/signal.h>
#include <stdlib.h>
pid_t parentPid=0;
pid_t f1,f2,f3;
pid_t p1,p2,p3;


int flag=0;
void intHandler(int sig){
	// we use this flag to stop the loop
	flag=1;
	
	// terminate only the ids whoch are not descendants and doesnot have gid as root gid
	if(getppid()!=parentPid && getpid() != getpgid(getpid())){
		printf("PID: %d  PPID: %d is terminated.\n", getpid(), getppid());
		
		// kill using sigkill
		kill(getpid(), SIGKILL);
	}
	
	//send signal to parent to execute the other part of code
	if(getpid()==parentPid){
		kill(parentPid,SIGUSR1);
	}

}

void tempHandler(int signo)
{
	// do nothing
}


int main(){
	
	int a = signal(SIGINT, intHandler);
	int b = signal (SIGUSR1,tempHandler);

	if(a<0) printf("Error in registering handler for SIGINT\n");
	if(b<0) printf("Error in registering handler for SIGUSR1\n");
	//getparent id
	parentPid= getpid();
	
	// fork 3 consecutive
	 f1=fork();
	 f2=fork();
	 f3=fork();
 
	// check if any error in forking
	if(f1<0 || f2<0 || f3<0){
		printf("Error in forking\n");
	}
		
	
	// if it is a child	
	if(f1==0 || f2==0 || f3==0 ){
		
		// set pgid to its parent
		setpgid(0,getppid());
		
		// loop till we receive ctrl c	
		while(1){
		//	stop loop if flag==1
			if(flag==1) break;
			printf("From Process %d\n", getpid());
			sleep(2);
		}
		
		
		/// infinite loop
		while(1){
				
				printf("This is from process: %d\n", getpid());
				sleep(2);
				

		}
	
		
	}
	
	else if(f1>0 && f2>0 && f3>0){
		
		// in parent 
		
		//wait for ctrl C where init handler sends signal to pause
		pause();
		p1=f1;
		p2=f2;
		p3=f3;
		//stopping the child processes
		kill(p1, SIGSTOP);
		kill(p2, SIGSTOP);
		kill(p3, SIGSTOP);

		
        while(1) {   
		        
           	printf("This is from process: %d\n", getpid());

			
            kill(p1, SIGCONT);
            sleep(2);
            kill(p1, SIGSTOP);
            
            
            kill(p2, SIGCONT);
            sleep(2);
            kill(p2, SIGSTOP);
            
            kill(p3, SIGCONT);
            sleep(2);
            kill(p3, SIGSTOP);
           
    	}
        
        wait(NULL);

}
}
