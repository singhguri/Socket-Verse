#include<stdio.h>
#include<string.h>
#include<pthread.h>
#include<stdlib.h>
#include<unistd.h>

pthread_t tid[5];
int amitojCount=6;
pthread_mutex_t amitojLock; // lock required

//thread function
void* amitojFunc(void *arg)
{
	
	// apply lock
    pthread_mutex_lock(&amitojLock);
	
	//dereference
	int *val= arg;
	
	// if val is 1 means it is in detached mode
    if(amitojCount>=1 && *val==1){
    	sleep(1);
    	//decrease the count variable
		amitojCount=amitojCount-1;
    	
		printf("Thread Id: %ld  Count: %d\n",pthread_self(),amitojCount);
    } 
    
    
    pthread_mutex_unlock(&amitojLock); // unlock the lock

    return NULL;
}

int main(void)
{
	
	pthread_attr_t attr; // attributes
	pthread_t tid[6]; // thread id array
	
	// init attr
	pthread_attr_init(&attr);

    int err;
    
    
    
	// initailizee amitoj lock
    if (pthread_mutex_init(&amitojLock, NULL) != 0) 
    {
        printf("\n failed initialization of lock\n");
        return 1;
    }
   
	int val =1;
	int val2=0;
	// create 6 alternate threads
	for(int i=0;i<3;i++){
		
		pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_JOINABLE);
		err = pthread_create(&(tid[2*i]), &attr,amitojFunc, &val2);
		
		pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);
		err = pthread_create(&(tid[2*i+1]), &attr,amitojFunc, &val);
		
        if (err != 0)
            printf("\nerror in creating thread\n");

	}
	
	//join for threads
	for(int i=0;i<6;i++){
		pthread_join(tid[i], NULL);
	}
   
 	//destroy amitoj lock
    pthread_mutex_destroy(&amitojLock);
    //destroy attribute
	pthread_attr_destroy(&attr); 

    printf("Main thread completes \n");
    return 0;
}
