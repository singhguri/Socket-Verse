/*
Name: Gurpreet Singh
Student Id: 110095558
Section: 2 (Tuesday 8:30AM - 11:30AM)
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <linux/limits.h>
#include <fcntl.h>
#include <dirent.h>

#define __USE_XOPEN_EXTENDED 1
#include <ftw.h>

// created a struct for clean code
struct
{
    char *excluded_ext[6];
    int count;

    const char *src_dir;
    char *dest_dir;
    char *mode;
} Common;

// Utility Functions
// function to update path with "/" in the end if it does not exist
char *update_path(char *path)
{
    if (path == NULL)
        return NULL;

    char *dirs = strtok(path, "/");

    if (dirs != NULL)
    {
        char *base = malloc(sizeof(char) * 4096);
        while (dirs != NULL)
        {
            strcat(base, dirs);
            strcat(base, "/");
            dirs = strtok(NULL, "/");
        }

        return base;
    }

    return "";
}

// function to create parent directory if operation performed on sub folder
char *create_parent_dir(char *dir_path)
{
    if (dir_path == NULL)
        return NULL;

    struct stat st;
    char *dirs = strtok(dir_path, "/");
    char *base = malloc(sizeof(char) * 4096);

    while (dirs != NULL)
    {
        strcat(base, dirs);
        strcat(base, "/");

        if (stat(base, &st) == -1)
        {
            if (mkdir(base, 0777) == -1)
            {
                perror("Error creating directory...\n");
                exit(1);
            }
        }
        dirs = strtok(NULL, "/");
    }

    char *final_path = strdup(base);
    free(base);

    return final_path;
}

// function to extract extension of a given file
char *get_extension(const char *filepath)
{
    if (filepath == NULL)
        return NULL;

    char *filename = strrchr(filepath, '/');
    if (filename == NULL)
        filename = (char *)filepath;
    else
        filename++;

    char *ext = strrchr(filename, '.');

    if (ext == NULL)
        return "";
    return ext;
}

// function to check if a substring exists in another string
int includes_str(const char *path)
{
    // get current file extension
    char *ext = get_extension(path);
    int res = 0;

    for (int i = 0; i < Common.count; i++)
    {
        char *final_ext = malloc(strlen(Common.excluded_ext[i]) + 2);
        if (final_ext == NULL)
        {
            perror("Memory allocation failed.\n");
            exit(EXIT_FAILURE);
        }
        final_ext[0] = '.';
        strcpy(final_ext + 1, Common.excluded_ext[i]);

        if (ext != NULL && strcmp(final_ext, ext) == 0)
        {
            res = 1;
            break;
        }

        free(final_ext);
    }

    return res;
}

// function to delete given directory
int delete_dir(const char *dirname)
{
    DIR *dir;
    struct dirent *entry;
    struct stat st;
    char path[4096];

    if (stat(dirname, &st) != -1)
    {
        dir = opendir(dirname);
        if (!dir)
        {
            perror("Error in opening dir\n");
            exit(1);
        }

        while ((entry = readdir(dir)) != NULL)
        {
            if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0)
                continue;

            snprintf(path, sizeof(path), "%s/%s", dirname, entry->d_name);

            struct stat st;
            if (stat(path, &st) == -1)
            {
                perror("Error in getting file info\n");
                continue;
            }

            if (S_ISDIR(st.st_mode))
                delete_dir(path);
            else
            {
                if (unlink(path) == -1)
                {
                    perror("Error in removing file\n");
                    continue;
                }
            }
        }

        closedir(dir);

        if (rmdir(dirname) == -1)
        {
            perror("Error in removing directory\n");
        }

        return 0;
    }
    return -1;
}

// Main Logic
int move_file(const char *src_path, const struct stat *sb, int typeflag, struct FTW *ftwbuf)
{
    struct stat st = {0};
    char dest_path[4096];
    char buffer[4096];
    ssize_t bytes_read, bytes_written;

    snprintf(dest_path, sizeof(dest_path), "%s%s", Common.dest_dir, src_path);

    if (Common.count == 0 || (Common.count > 0 && !includes_str(src_path)))
    {
        if (typeflag == FTW_F)
        {
            // Move file
            // open source file
            int src_fd = open(src_path, O_RDWR);
            if (src_fd == -1)
            {
                perror("Error opening source file\n");
                exit(EXIT_FAILURE);
            }

            // open destination file
            int dest_fd = open(dest_path, O_CREAT | O_WRONLY | O_TRUNC, 0644);
            if (dest_fd == -1)
            {
                close(src_fd);
                perror("Error opening destination file\n");
                exit(EXIT_FAILURE);
            }
            // read source file
            while ((bytes_read = read(src_fd, buffer, sizeof(buffer))) > 0)
            {
                // write destination file
                bytes_written = write(dest_fd, buffer, bytes_read);
                if (bytes_written == -1)
                {
                    perror("Error writing to destination file\n");
                    break;
                }
            }

            // close both files
            close(src_fd);
            close(dest_fd);

            // return error if nothing was read
            if (bytes_read == -1)
            {
                perror("Error reading from source file");
                exit(EXIT_FAILURE);
            }
        }
        else if (typeflag == FTW_D)
        {
            // make directory if it does not exist
            if (stat(dest_path, &st) == -1)
            {
                if (mkdir(dest_path, 0777) == -1)
                {
                    perror("Error in creating directory while move operation\n");
                    exit(EXIT_FAILURE);
                }
            }
        }
    }

    return 0;
}

// function to copy file and called by nftw
int copy_file(const char *src_path, const struct stat *sb, int typeflag, struct FTW *ftwbuf)
{
    // create destination directory if it does not exist
    struct stat status = {0};
    if (stat(Common.dest_dir, &status) == -1)
    {
        if (mkdir(Common.dest_dir, 0777) == -1)
        {
            perror("Error creating directory...\n");
            exit(1);
        }
    }

    // declare some auxillary variables
    struct stat st = {0};
    char dst_path[4096];
    char buffer[4096];
    ssize_t bytes_read, bytes_written;

    // concatinate destination directory and source directory
    snprintf(dst_path, sizeof(dst_path), "%s%s", Common.dest_dir, src_path);

    if (Common.count == 0 || (Common.count > 0 && !includes_str(src_path)))
    {
        if (typeflag == FTW_D)
        {
            // make directory if it does not exist
            if (stat(dst_path, &st) == -1)
            {
                if (mkdir(dst_path, 0777) == -1)
                {
                    perror("Error in creating directory while copy operation\n");
                    exit(EXIT_FAILURE);
                }
            }
        }
        else if (typeflag == FTW_F)
        {
            // copy file
            // open source file
            int src_fd = open(src_path, O_RDWR);
            if (src_fd == -1)
            {
                perror("Error opening source file\n");
                exit(EXIT_FAILURE);
            }
            // open destination file
            int dest_fd = open(dst_path, O_CREAT | O_WRONLY | O_TRUNC, 0644);
            if (dest_fd == -1)
            {
                close(src_fd);
                perror("Error opening destination file\n");
                exit(EXIT_FAILURE);
            }

            // read source file
            while ((bytes_read = read(src_fd, buffer, sizeof(buffer))) > 0)
            {
                // write destination file
                bytes_written = write(dest_fd, buffer, bytes_read);

                // return an error if no bytes are written
                if (bytes_written == -1)
                {
                    perror("Error writing to destination file\n");
                    break;
                }
            }

            // close opened files
            close(src_fd);
            close(dest_fd);

            // return an error if no bytes are read
            if (bytes_read == -1)
            {
                perror("Error reading from source file");
                exit(EXIT_FAILURE);
            }
        }
    }

    return 0;
}

int main(int argc, char *argv[])
{
    // basic condition: argument check
    if (argc < 4)
    {
        printf("Usage: %s [source_dir] [destination_dir] [options] <extension list>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    // get source & destination paths
    Common.src_dir = strdup(argv[1]);
    Common.dest_dir = argv[2];
    Common.mode = argv[3];

    if (argc > 4)
    {
        // initialize extension count
        Common.count = 0;
        // get extensions
        for (int i = 4; i < argc; i++)
        {
            Common.excluded_ext[Common.count] = argv[i];
            Common.count++;
        }
    }

    // crete parent directory if they do not exist
    Common.dest_dir = create_parent_dir(Common.dest_dir);

    if (Common.dest_dir == NULL || strlen(Common.dest_dir) == 0)
    {
        perror("Error in destination...\n");
        exit(EXIT_FAILURE);
    }

    // compare mode to check which operation to perform
    if (strcmp(Common.mode, "-mv") == 0)
    {
        // call nftw with move_file function
        if (nftw(Common.src_dir, move_file, 20, FTW_PHYS) == -1)
        {
            perror("Failed to move files\n");
            exit(EXIT_FAILURE);
        }

        // delete source directory after move process completes
        if (delete_dir(Common.src_dir) != -1)
            printf("Files moved succesfully.\n");
    }
    else if (strcmp(Common.mode, "-cp") == 0)
    {
        // call nftw with move_file function
        if (nftw(Common.src_dir, copy_file, 20, FTW_PHYS) == -1)
        {
            perror("Failed to copy files\n");
            exit(EXIT_FAILURE);
        }

        printf("Files copied succesfully.\n");
    }

    return 0;
}
